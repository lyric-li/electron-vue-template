import axios from 'axios'
import Qs from 'qs'
// import encrypt from './encrypt'

const http = axios.create({
  baseURL: '',
  transformRequest: [
    data => {
      console.info('请求参数:', data)
      // data = encrypt(data)
      data = {
        REQ_MESSAGE: data
      }
      data = Qs.stringify(data)
      return data
    }
  ],
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
  },
  timeout: 30000
})

export default http
