import http from './http'

const httpclient = {
  async post (url, params) {
    try {
      const res = await http.post(url, params)
      const data = res.data
      console.log('请求响应结果:', data)
      if (data.REP_HEAD.TRAN_CODE === '000000') {
        console.info('请求成功:', data.REP_BODY)
        return {
          code: '1',
          result: data.REP_BODY
        }
      } else {
        console.error('请求失败:', data.REP_HEAD.TRAN_RSPMSG)
        return {
          code: '0'
        }
      }
    } catch (error) {
      console.error('请求异常:', error)
      return {
        code: '-1'
      }
    }
  },
  async get (url, params) {
    try {
      const res = await http.post(url, {params})
      const data = res.data
      if (data.REP_HEAD.TRAN_CODE === '000000') {
        console.info('请求成功:', data.REP_BODY)
        return {
          code: '1',
          result: data.REP_BODY
        }
      } else {
        console.info('请求失败:', data)
        return {
          code: '0'
        }
      }
    } catch (error) {
      console.error('请求异常:', error)
      return {
        code: '-1'
      }
    }
  }
}

export default httpclient
