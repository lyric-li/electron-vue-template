const path = require('path')

module.exports = {
  render: {
    bundleRenderer: {
      cache: require('lru-cache')({
        max: 1000,
        maxAge: 1000 * 60 * 15
      })
    }
  },
  /*
  ** Headers of the page
  */
  head: {
    title: 'nuxt-template',
    meta: [
      {charset: 'utf-8'},
      {name: 'viewport', content: 'width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no,minimal-ui'},
      {hid: 'description', name: 'description', content: 'Nuxt.js project'}
    ],
    link: [
      {rel: 'icon', type: 'image/x-icon', href: '/favicon.ico'},
      {rel: 'stylesheet', href: 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'}
    ]
  },
  /*
  ** Global CSS
  */
  css: [
    'element-ui/lib/theme-default/index.css',
    {src: '~/assets/styl/app.styl'}
  ],
  /*
  ** Customize the progress-bar color
  */
  loading: {color: '#3B8070'},
  /*
   *  自定义页面切换过渡效果
   */
  transition: 'slide-fade',
  /*
  ** Build configuration
  */
  build: {
    analyze: true,
    extend (config, ctx) {
      if (ctx.dev && ctx.isClient) {
        config.module.rules.push({
          enforce: 'pre',
          test: /\.(js|vue)$/,
          loader: 'eslint-loader',
          exclude: /(node_modules)/
        })
      }
      config.resolve.alias['~/utils'] = path.join(__dirname, 'utils')
    },
    postcss: [
      // 自动补全css3前缀
      require('autoprefixer')({
        browsers: ['last 3 versions']
      })
    ],
    // 将重复引用的(第三方/自有)模块添加到vendor.bundle.js
    vendor: [
      'axios',
      'element-ui'
    ]
  },
  plugins: [
    {src: '~/plugins/element-ui.js', ssr: true}
  ],
  router: {
    scrollBehavior: function (to, from, savedPosition) {
      return {x: 0, y: 0}
    }
  }
}
